---
name: add-site
description: Use when adding a new streaming site / scraper to the Cumination Kodi addon (plugin.video.cumination) — e.g. "neue Seite hinzufügen", "Scraper für X schreiben", "Seite Y integrieren". Führt Live-Analyse (wahlweise Playwright, WebFetch oder Seitenquelltext), adaptive Generierung des Site-Files und Verifikation samt Begleitartefakten durch.
---

# Neue Adultsite zu Cumination hinzufügen

Erstellt einen neuen Site-Scraper unter `resources/lib/sites/<name>.py` aus der Live-Analyse
der Zielseite und legt alle Begleitartefakte an. Folge den Phasen in Reihenfolge; lege pro
Phase einen TodoWrite-Eintrag an.

**Analyse-Methode:** Live-Analyse (Phase 1) und Verifikation (Phase 4) laufen über **eine vom
Nutzer in Phase 0 gewählte Methode** — gleichrangig, keine Empfehlung:
- **Playwright MCP** — voller Browser inkl. Network-Tab und JS-Rendering (Repo enthält `.mcp.json`).
- **WebFetch** — schneller Abruf der Seite, Antwort als Markdown (kein roher HTML, kein Network-Tab).
- **Seitenquelltext** — roher HTML-Quelltext der Seite (exakte Selektoren, aber kein JS/Network-Tab).

Dieselbe Methode gilt für Analyse **und** Verifikation. Fragen, die die gewählte Methode nicht
beantworten kann (z. B. versteckte JSON-API, JS-gerenderte Listen), klärst du über eine
**manuelle DevTools-Anleitung** an den Nutzer (siehe Phase 1) und/oder gezielte Rückfragen.
Wird Playwright gewählt, ist aber der MCP-Server nicht verbunden: halte an und biete an, ihn zu
aktivieren **oder** eine andere Methode zu nehmen.

**Referenzdateien (immer zuerst lesen, nicht aus dem Gedächtnis raten):**
- `reference/helper-api.md` — exakte Signaturen von `site`/`utils`/`VideoPlayer`.
- `reference/scraper-template.py` — Boilerplate zum Kopieren.
- `reference/site-patterns.md` — Muster je Datenquelle/Stream-Typ.
- `reference/registration-checklist.md` — Begleitartefakte mit Pfaden/Formaten.
- Repo-Beispiel: `resources/lib/sites/beeg.py`.

## Phase 0 — Eingaben sammeln
Erfrage / kläre: Ziel-URL, gewünschter Anzeige-Titel, interner `name` (kurz, kleingeschrieben,
eindeutig). Prüfe Eindeutigkeit: `ls resources/lib/sites/<name>.py` darf nicht existieren.
**Frage außerdem die Analyse-Methode ab** (gleichrangig, ohne Empfehlung): **Playwright MCP**,
**WebFetch** oder **Seitenquelltext**. Bestätige die Verfügbarkeit der gewählten Methode (bei
Playwright: ist der MCP-Server verbunden?).

## Phase 1 — Analysieren (gewählte Methode), Abschluss erst bei ≥95 % Konfidenz
Untersuche die Ziel-URL systematisch — unabhängig von der Methode dieselben Punkte:
- Landeseite: Wie sind Videolisten aufgebaut — HTML-Karten oder JSON-Endpoint?
- Gibt es Kategorien, Suche, Pagination? Notiere das URL-Schema je Bereich.
- Videoseite: Weg zum Stream — direkter `m3u8`/`mp4`-Link, eingebetteter Hoster (für
  `resolveurl`) oder JSON-API?

**Je nach gewählter Methode:**
- **Playwright** — Seite öffnen, `browser_snapshot` (mit `filename`), `browser_network_requests`
  für JSON-Endpoints, Videoseite öffnen und den Stream-Weg verfolgen.
- **WebFetch** — Seite mit gezielten Prompts abrufen (Videoliste, Kategorien-Links,
  Pagination-Muster, Link zur Videoseite). Liefert Markdown — keine exakten Selektoren, kein
  Network-Tab; roh-HTML bei Bedarf über die Quelltext-Methode nachholen.
- **Seitenquelltext** — rohen HTML-Quelltext abrufen (z. B. `curl -sL <url>` bzw. Browser
  „Seitenquelltext anzeigen"; `utils.getHtml` ist außerhalb Kodi nicht ausführbar). Exakte
  HTML-Struktur für Regex, aber kein JS-gerenderter Inhalt und kein Network-Tab.

**Offene Fragen → manuelle DevTools-Anleitung (besonders ohne Playwright):** Bitte den Nutzer,
im Browser die Entwickler-Tools zu nutzen und das Ergebnis zurückzumelden, z. B.:
- *Versteckte JSON-API / JS-gerenderte Liste:* DevTools öffnen (F12 / Rechtsklick →
  „Untersuchen") → Reiter **Network** → Filter **Fetch/XHR** → Seite neu laden → die Anfrage
  finden, die die Videodaten liefert; URL und Response-Vorschau zurückgeben.
- *Exakter Listen-/Karten-HTML:* Rechtsklick auf eine Videokachel → „Untersuchen" → das
  umschließende Element kopieren.
- *Stream-Quelle:* auf der Videoseite Network → Filter **Media** bzw. nach `.m3u8`/`.mp4`
  suchen, während das Video startet.

**Konfidenz-Gate:** Bewerte danach explizit (als Prozentwert) deine Konfidenz, jeden relevanten
Bereich verstanden zu haben: Listenstruktur, Pagination-Schema, Kategorien/Suche,
Stream-Extraktionsweg. **Liegt die Konfidenz unter 95 %, gehe NICHT zu Phase 2.** Stelle dem
Nutzer stattdessen gezielte Fragen (z.B. „Welcher Link führt zum echten Video?", „Gibt es eine
versteckte JSON-API?", „Stimmt dieses Pagination-Muster?"), nutze die DevTools-Anleitung oben
und/oder analysiere weiter. Wiederhole, bis du ≥95 % erreichst. Nenne dem Nutzer deine Konfidenz,
bevor du weitergehst.

## Phase 2 — Klassifizieren
Lege zwei Achsen fest (steuern das Template):
- **Datenquelle:** JSON-API (`json.loads(utils.getHtml(...))`) vs. HTML-Scrape (Regex).
- **Stream-Typ:** direkter Link → `VideoPlayer.play_from_direct_link`; eingebetteter Hoster →
  `play_from_site_link`/`play_from_html`; Webcam → `webcam=True` im Konstruktor.
Wähle das passende Muster aus `reference/site-patterns.md`.

## Phase 3 — Generieren (adaptiv)
Kopiere `reference/scraper-template.py` nach `resources/lib/sites/<name>.py` und fülle es:
- `AdultSite(name, "[COLOR hotpink]Titel[/COLOR]", url, "<name>.png", "<name>")`.
- Generiere **nur** die Funktionen, die die Seite real anbietet (Phase 2). `Main` trägt
  `default_mode=True`. Pagination als „Next Page"-Dir-Item. Verwende Helfer-Signaturen aus
  `reference/helper-api.md`. Jede Liste endet mit `utils.eod()`.

## Phase 4 — Verifizieren (gewählte Methode)
Prüfe die generierten Selektoren/URLs gegen die Live-Seite **mit derselben Methode wie in
Phase 1**: Liefert die Listen-URL die erwarteten Titel/Thumbnails? Stimmt die Pagination-URL?
Führt die Extraktion zur erwarteten Stream-Quelle? Bei Abweichung → zurück zu Phase 3. Reine
Browser-/Abruf-Verifikation (kein Python außerhalb Kodi ausführbar — Imports `xbmc`/`xbmcgui`
existieren nur in Kodi).

**Echte Abspielbarkeit ohne Playwright nicht im Browser bestätigbar:** Zeige dem Nutzer die
konkreten URLs zum **manuellen Abruf/Test** an — die konstruierte Listen-/API-URL und die
extrahierte Stream-URL (`.m3u8`/`.mp4`) bzw. die Hoster-Seiten-URL — damit er sie selbst im
Browser/Player öffnen und bestätigen kann.

## Phase 5 — Begleitartefakte
Arbeite `reference/registration-checklist.md` ab: about-Datei, Icon/Bild, changelog +
addon.xml-Versions-Bump (**Buchstabe anhängen**, nicht neue Zahl), ggf. Sprach-Strings.

## Phase 6 — Abschluss
Weise auf den manuellen Kodi-Smoke-Test hin (keine automatisierten Tests). Erinnere daran, dass
`utils.getHtml` gecacht ist → beim erneuten Testen `utils.clear_cache()` bzw. Cache leeren.
