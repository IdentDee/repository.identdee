'''
    Cumination
    Copyright (C) 2021 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re

from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite('chezcathy', "[COLOR hotpink]ChezCathy[/COLOR]", 'https://chezcathy.com', 'chezcathy.png', 'chezcathy')
BASE_URL = 'https://chezcathy.com'

# Die Kategorien-Auswahl der Seite wird per JavaScript (SvelteKit) gerendert und steht NICHT im
# rohen HTML, das getHtml erhaelt. Es ist ein fester, kuratierter Satz -> hier hinterlegt.
# Pro Sektion: (Anzeigename, slug zur Seite 1). Die Zielseiten liefern normale video-card-Listen.
CATEGORIES = {
    'sex': [
        ('Amateur', '/sex/tag/amateur/1'),
        ('Big Tits Natural', '/sex/tag/big-tits-natural/1'),
        ('Blonde', '/sex/tag/blonde/1'),
        ('Blonde Gros Seins', '/sex/tag/blonde-gros-seins/1'),
        ('Blonde Teen Porn', '/sex/tag/blonde-teen-porn/1'),
        ('Brune Gros Seins', '/sex/tag/brune-gros-seins/1'),
        ('Chatte Poilue', '/sex/tag/chatte-poilue/1'),
        ('Collants', '/sex/tag/collants/1'),
        ('Cunnilingus', '/sex/tag/cunnilingus/1'),
        ('Dogging', '/sex/tag/dogging/1'),
        ('Doggystyle', '/sex/tag/doggystyle/1'),
        ('Ejac Faciale', '/sex/tag/ejac-faciale/1'),
        ('Ejacs', '/sex/tag/ejacs/1'),
        ('Fellation', '/sex/tag/fellation/1'),
        (u'Film Porno Scénario', '/sex/tag/film-porno-scenario/1'),
        ('Gorge Profonde', '/sex/tag/gorge-profonde/1'),
        ('Gros Seins', '/sex/tag/gros-seins/1'),
        ('Grosse Bite', '/sex/tag/grosse-bite/1'),
        ('Interracial', '/sex/tag/interracial/1'),
        ('Jeune 18 21ans', '/sex/tag/jeune-18-21ans/1'),
        ('Latina Porn', '/sex/tag/latina-porn/1'),
        ('Lesbienne', '/sex/tag/lesbienne/1'),
        (u'Masturbation Féminine', '/sex/tag/masturbation-feminine/1'),
        ('MILF Gros Seins', '/sex/tag/milf-gros-seins/1'),
        ('Milf Porn', '/sex/tag/milf-porn/1'),
        ('PAWG', '/sex/tag/pawg/1'),
        ('Petits Seins', '/sex/tag/petits-seins/1'),
        ('Porn HD', '/sex/tag/porn-hd/1'),
        ('Porno Anal', '/sex/tag/porno-anal/1'),
        ('Porno Black', '/sex/tag/porno-black/1'),
        ('Porno Brune', '/sex/tag/porno-brune/1'),
        ('Porno Chic', '/sex/tag/porno-chic/1'),
        ('Porno Mature', '/sex/tag/porno-mature/1'),
        ('Porno Stars', '/sex/tag/porno-stars/1'),
        ('POV Porn', '/sex/tag/pov-porn/1'),
        ('Sextoy Porno', '/sex/tag/sextoy-porno/1'),
        ('Soft', '/sex/tag/soft/1'),
        ('Teen Blowjob', '/sex/tag/teen-blowjob/1'),
        ('Teen Porn', '/sex/tag/teen-porn/1'),
        ('Trio', '/sex/tag/trio/1'),
    ],
}


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Videos[/COLOR]', BASE_URL + '/sex/1', 'List', site.img_cat)
    site.add_dir('[COLOR hotpink]Videos - Categories[/COLOR]', 'sex', 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]Extreme[/COLOR]', BASE_URL + '/extreme-sex/1', 'List', site.img_cat)
    utils.eod()


@site.register()
def Categories(url):
    for label, slug in CATEGORIES.get(url, []):
        site.add_dir(label, BASE_URL + slug, 'List', site.img_cat)
    utils.eod()


@site.register()
def List(url):
    listhtml = utils.getHtml(url, BASE_URL)

    pattern = re.compile(
        r'<div\s+class="video-card\b[^>]*?>\s*<a\s+href="(?P<url>[^"]+)".*?>'
        r'.*?bg-yellow-300[^>]*>(?P<duration>\d{1,2}:\d{2})\s*Min</div>'
        r'.*?<img\s+src="(?P<thumb>[^"]+)".*?<p.*?text-sm.*?>(?P<title>[^<]+)',
        re.DOTALL | re.IGNORECASE
    )

    for match in pattern.finditer(listhtml):
        title = utils.cleantext(match.group('title'))
        site.add_download_link(title, BASE_URL + match.group('url'), 'Playvid', match.group('thumb'), duration=match.group('duration'))

    # Roh ausgeliefertes HTML nutzt einen "&gt;"-Pfeil als Next-Link (kein JS/sr-only).
    # Die Gesamtseitenzahl wechselt je Seite (rollendes Fenster) und ist daher nicht verlaesslich.
    navblock = re.search(r'<nav\b[^>]*aria-label="Page navigation".*?</nav>', listhtml, re.DOTALL | re.IGNORECASE)
    if navblock:
        nextlink = re.search(r'href="(?P<next_slug>[^"]*?/(?P<next>\d+))"[^>]*>\s*&gt;\s*</a>', navblock.group(0), re.IGNORECASE)
        if nextlink:
            label = 'Next Page ({0})'.format(nextlink.group('next'))
            site.add_dir(label, BASE_URL + nextlink.group('next_slug'), 'List', site.img_next)
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(18, "[CR]Loading video page[CR]")
    videopage = utils.getHtml(url, BASE_URL)
    videolink = re.compile(r'<source\b[^>]*?\bsrc="([^"]+\.mp4[^"]*)"', re.IGNORECASE).search(videopage).group(1)
    vp.play_from_direct_link(videolink)
