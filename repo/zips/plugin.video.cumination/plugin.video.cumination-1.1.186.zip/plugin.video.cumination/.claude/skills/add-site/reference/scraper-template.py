'''
    Cumination
    Copyright (C) 2021 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
import json  # nur falls die Seite eine JSON-API nutzt
from resources.lib import utils
from resources.lib.adultsite import AdultSite
from six.moves import urllib_parse  # nur falls quote_plus o.ä. gebraucht wird

# name | title (mit BBCode-Farbe) | basis-url | bild in resources/images/ | about-datei (ohne .txt)
site = AdultSite("SITENAME", "[COLOR hotpink]SITETITLE[/COLOR]", "https://SITEURL/", "SITENAME.png", "SITENAME")


@site.register(default_mode=True)
def Main():
    # Nur die Bereiche eintragen, die die Seite wirklich hat (adaptiv).
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', site.url + 'categories/', 'Categories', site.img_cat)
    site.search_dir(site.url + 'search/', 'List')   # weglassen, wenn keine Suche existiert
    List(site.url + 'latest/')


@site.register()
def List(url, page=1):
    html = utils.getHtml(url, site.url)
    # HTML-Scrape: ein Regex je Videokarte (url, img, name) — siehe site-patterns.md
    # JSON-API: stattdessen  jdata = json.loads(html)  und über jdata iterieren.
    for vidurl, img, name in re.compile(r'VIDEO_ITEM_REGEX', re.DOTALL).findall(html):
        name = utils.cleantext(name)
        site.add_download_link(name, vidurl, 'Playvid', img, name)
    # Pagination (weglassen, wenn einseitig):
    utils.next_page(site, 'List', html, r'NEXT_PAGE_URL_REGEX')
    utils.eod()


@site.register()
def Categories(url):
    html = utils.getHtml(url, site.url)
    for caturl, name in re.compile(r'CATEGORY_REGEX', re.DOTALL).findall(html):
        site.add_dir(utils.cleantext(name), caturl, 'List', site.img_cat)
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    # Variante A — eingebetteter Hoster / Seite mit Quelle (resolveurl):
    vp.play_from_site_link(url, site.url)
    # Variante B — direkter Stream-Link (m3u8/mp4):
    # vp.play_from_direct_link(url + '|Referer={}'.format(site.url))
    # Variante C — JSON-API liefert Link:
    # html = utils.getHtml(url, site.url); videourl = json.loads(html)['SOME_KEY']
    # vp.play_from_direct_link(videourl)
