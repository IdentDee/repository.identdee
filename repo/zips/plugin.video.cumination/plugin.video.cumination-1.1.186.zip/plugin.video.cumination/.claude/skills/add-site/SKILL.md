---
name: add-site
description: Use when adding a new streaming site / scraper to the Cumination Kodi addon (plugin.video.cumination) — e.g. "neue Seite hinzufügen", "Scraper für X schreiben", "Seite Y integrieren". Führt Live-Analyse (Playwright), adaptive Generierung des Site-Files und Browser-Verifikation samt Begleitartefakten durch.
---

# Neue Adultsite zu Cumination hinzufügen

Erstellt einen neuen Site-Scraper unter `resources/lib/sites/<name>.py` aus der Live-Analyse
der Zielseite und legt alle Begleitartefakte an. Folge den Phasen in Reihenfolge; lege pro
Phase einen TodoWrite-Eintrag an.

**Voraussetzung:** Playwright MCP muss verfügbar sein (Repo enthält `.mcp.json`). Ist er es
nicht, halte an und bitte den Nutzer, ihn zu aktivieren.

**Referenzdateien (immer zuerst lesen, nicht aus dem Gedächtnis raten):**
- `reference/helper-api.md` — exakte Signaturen von `site`/`utils`/`VideoPlayer`.
- `reference/scraper-template.py` — Boilerplate zum Kopieren.
- `reference/site-patterns.md` — Muster je Datenquelle/Stream-Typ.
- `reference/registration-checklist.md` — Begleitartefakte mit Pfaden/Formaten.
- Repo-Beispiel: `resources/lib/sites/beeg.py`.

## Phase 0 — Eingaben sammeln
Erfrage / kläre: Ziel-URL, gewünschter Anzeige-Titel, interner `name` (kurz, kleingeschrieben,
eindeutig). Prüfe Eindeutigkeit: `ls resources/lib/sites/<name>.py` darf nicht existieren.

## Phase 1 — Analysieren (Playwright), Abschluss erst bei ≥95 % Konfidenz
Öffne die Ziel-URL mit Playwright und untersuche systematisch:
- Landeseite: Wie sind Videolisten aufgebaut — HTML-Karten oder JSON-Endpoint (Network-Tab)?
- Gibt es Kategorien, Suche, Pagination? Notiere das URL-Schema je Bereich.
- Öffne eine Videoseite: Weg zum Stream — direkter `m3u8`/`mp4`-Link, eingebetteter Hoster
  (für `resolveurl`) oder JSON-API?

**Konfidenz-Gate:** Bewerte danach explizit (als Prozentwert) deine Konfidenz, jeden relevanten
Bereich verstanden zu haben: Listenstruktur, Pagination-Schema, Kategorien/Suche,
Stream-Extraktionsweg. **Liegt die Konfidenz unter 95 %, gehe NICHT zu Phase 2.** Stelle dem
Nutzer stattdessen gezielte Fragen (z.B. „Welcher Link führt zum echten Video?", „Gibt es eine
versteckte JSON-API?", „Stimmt dieses Pagination-Muster?") und/oder analysiere weiter.
Wiederhole, bis du ≥95 % erreichst. Nenne dem Nutzer deine Konfidenz, bevor du weitergehst.

## Phase 2 — Klassifizieren
Lege zwei Achsen fest (steuern das Template):
- **Datenquelle:** JSON-API (`json.loads(utils.getHtml(...))`) vs. HTML-Scrape (Regex).
- **Stream-Typ:** direkter Link → `VideoPlayer.play_from_direct_link`; eingebetteter Hoster →
  `play_from_site_link`/`play_from_html`; Webcam → `webcam=True` im Konstruktor.
Wähle das passende Muster aus `reference/site-patterns.md`.

## Phase 3 — Generieren (adaptiv)
Kopiere `reference/scraper-template.py` nach `resources/lib/sites/<name>.py` und fülle es:
- `AdultSite(name, "[COLOR hotpink]Titel[/COLOR]", url, "<name>.png", "<name>")`.
- Generiere **nur** die Funktionen, die die Seite real anbietet (Phase 2). `Main` trägt
  `default_mode=True`. Pagination als „Next Page"-Dir-Item. Verwende Helfer-Signaturen aus
  `reference/helper-api.md`. Jede Liste endet mit `utils.eod()`.

## Phase 4 — Verifizieren (Playwright)
Prüfe die generierten Selektoren/URLs gegen die Live-Seite: Liefert die Listen-URL die
erwarteten Titel/Thumbnails? Stimmt die Pagination-URL? Führt die Video-Extraktion zu einer
echten, abspielbaren Stream-URL? Bei Abweichung → zurück zu Phase 3. Reine Browser-Verifikation
(kein Python außerhalb Kodi ausführbar — Imports `xbmc`/`xbmcgui` existieren nur in Kodi).

## Phase 5 — Begleitartefakte
Arbeite `reference/registration-checklist.md` ab: about-Datei, Icon/Bild, changelog +
addon.xml-Versions-Bump (**Buchstabe anhängen**, nicht neue Zahl), ggf. Sprach-Strings.

## Phase 6 — Abschluss
Weise auf den manuellen Kodi-Smoke-Test hin (keine automatisierten Tests). Erinnere daran, dass
`utils.getHtml` gecacht ist → beim erneuten Testen `utils.clear_cache()` bzw. Cache leeren.
