# Site-Muster

Wähle nach der Klassifikation (Phase 2) das passende Muster. Kombinierbar: Datenquelle (HTML
vs. JSON) × Stream-Typ (direkt vs. Hoster vs. JSON).

## A. HTML-Liste (Regex)
```python
html = utils.getHtml(url, site.url)
for vidurl, img, name in re.compile(r'<a href="([^"]+)".*?<img src="([^"]+)".*?title="([^"]+)"', re.DOTALL).findall(html):
    site.add_download_link(utils.cleantext(name), vidurl, 'Playvid', img, name)
utils.next_page(site, 'List', html, r'<a[^>]+class="next"[^>]+href="([^"]+)"')
utils.eod()
```

## B. JSON-API-Liste
```python
jdata = json.loads(utils.getHtml(url, site.url))
for v in jdata['videos']:
    site.add_download_link(v['title'], v['url'], 'Playvid', v['thumb'], v.get('desc', ''),
                           duration=v.get('duration', ''), quality=v.get('quality', ''))
utils.eod()
```

## C. Stream: direkter Link
```python
vp = utils.VideoPlayer(name, download)
vp.play_from_direct_link(videourl + '|Referer={}'.format(site.url))
```

## D. Stream: eingebetteter Hoster (resolveurl)
```python
vp = utils.VideoPlayer(name, download)
vp.play_from_site_link(url, site.url)   # lädt Seite, scrapt Hoster-Links, löst via resolveurl auf
```

## E. Webcam-Seite
`AdultSite(..., webcam=True)` → der Titel bekommt automatisch „ - webcams". Listen verlinken
i.d.R. direkt auf einen Live-Stream (`play_from_direct_link`); Auto-Refresh der Vorschaubilder
steuert die Addon-Einstellung `webcam`.

## Kontextmenü-Eintrag (optional)
```python
cm_url = utils.addon_sys + "?mode=SITENAME.SomeFunc&url=" + urllib_parse.quote_plus(target)
cm = [('[COLOR violet]Label[/COLOR]', 'RunPlugin(' + cm_url + ')')]
site.add_download_link(name, vidurl, 'Playvid', img, name, contextm=cm)
```

> Die Regex/JSON-Pfade oben sind Vorlagen — passe Feldnamen und Muster an die in Phase 1
> analysierte Struktur an und verifiziere sie in Phase 4 gegen die Live-Seite.
