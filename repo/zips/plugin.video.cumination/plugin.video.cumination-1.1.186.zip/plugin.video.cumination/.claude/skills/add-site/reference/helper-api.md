# Helfer-API für Site-Scraper

Ein Site-File erstellt `site = AdultSite(...)` und ruft darüber `site.add_dir` /
`site.add_download_link` / `site.search_dir` auf (Wrapper aus `url_dispatcher.py`, die
`self.module_name` voranstellen). Alles andere kommt aus `resources.lib.utils` (`utils`) und
`resources.lib.basics`.

## AdultSite / Registrierung (`resources/lib/adultsite.py`)
- `AdultSite(name, title, url, image=None, about=None, webcam=False)` — `image` ist ein
  Dateiname in `resources/images/`; `about` ein Dateiname (ohne `.txt`) in `resources/about/`.
- `@site.register(default_mode=True)` — markiert die Einstiegsfunktion (genau eine pro Seite).
- `@site.register()` — registriert jede weitere aufrufbare Funktion.
- Bereitgestellte Bild-Attribute: `site.img_search`, `site.img_cat`, `site.img_next`, `site.url`.

## Listen-/Item-Helfer (`url_dispatcher.py` → `basics.py`)
- `site.add_dir(name, url, mode, iconimage=None, page=None, channel=None, section=None, keyword='', Folder=True, about=None, custom=False, list_avail=True, listitem_id=None, custom_list=False, contextm=None, desc='')`
- `site.add_download_link(name, url, mode, iconimage, desc='', stream=None, fav='add', noDownload=False, contextm=None, fanart=None, duration='', quality='')`
- `site.search_dir(url, mode, page=None)`
- `utils.eod()` — beendet jede Verzeichnis-Auflistung (am Ende jeder Listenfunktion aufrufen).
- `utils.next_page(site, list_mode, html, re_npurl, re_npnr=None, re_lpnr=None, videos_per_page=None, contextm=None, baseurl=None)` — fügt automatisch ein „Next Page"-Item anhand eines Regex für die Next-URL hinzu.

## HTTP / Parsing (`utils.py`)
- `utils.getHtml(url, referer='', headers=None, NoCookie=None, data=None, error='return', ignoreCertificateErrors=False)` — **gecacht** über `script.common.plugin.cache`.
- `utils.postHtml(url, form_data={}, headers={}, json_data={}, compression=True, NoCookie=None)`
- `utils.cleantext(text)`, `utils.cleanhtml(raw_html)` — HTML/Entities säubern.
- `utils.prefquality(video_list, sort_by=None, reverse=False)` — wählt bevorzugte Qualität aus einem dict {label: url}.
- `utils.selector(dialog_name, select_from, ...)` — Auswahldialog.
- Flags: `utils.PY3`, `utils.KODIVER`, `utils.addon_sys` (für Kontextmenü-`RunPlugin`-Strings).

## Wiedergabe (`utils.VideoPlayer`, `utils.py`)
- `VideoPlayer(name, download=False, regex=..., direct_regex=..., IA_check='check')`
- `.play_from_site_link(url, referrer='')` — lädt die Seite und löst Hoster/Direktlinks auf.
- `.play_from_html(html, url=None)` — wie oben, wenn das HTML schon vorliegt.
- `.play_from_direct_link(direct_link)` — direkter `m3u8`/`mp4`-Link; an `|Referer=<url>` anhängbar.
- `.progress.update(percent, message)` — Fortschrittsanzeige.
