# Registrierungs-Checkliste (Begleitartefakte)

Nach dem Generieren und Verifizieren des Scrapers diese Artefakte anlegen.

## 1. about-Datei (Pflicht)
`resources/about/<name>.txt` — sonst schlägt der „About"-Kontextmenüpunkt fehl. Format wie
bestehende Dateien:
```
Site URL: https://<site>/
Contact: https://<site>/contact
DMCA: https://<site>/dmca
```
Im Konstruktor referenziert über das `about`-Argument (= `<name>`).

## 2. Icon/Bild
`resources/images/<name>.png` (auch `.jpg`/`.gif` zulässig). Logo der Seite holen und ablegen;
im `AdultSite(...)`-Konstruktor als Bilddateiname referenzieren.

## 3. changelog.txt + addon.xml-Version
- `changelog.txt`: neuen Eintrag oben ergänzen, Format `[B]Version <ver>[/B]` + Zeile(n)
  `- <name> - neue Seite`.
- `addon.xml`: **einzige Versionsquelle**. Version hochsetzen, indem ein **Buchstabe angehängt**
  wird (z.B. `1.1.186` → `1.1.186a`) — keine neue Zahl vergeben (Projektregel).

## 4. Sprach-Strings (nur falls neue benutzersichtbare Texte)
Bei den meisten Seiten nicht nötig (sichtbare Strings stehen oft inline mit BBCode). Falls doch,
sind ZWEI Stellen nötig:
1. In `resources/lib/strings.py` dem `STRINGS`-Dict einen benannten Schlüssel → numerische ID
   zuordnen, z.B. `'my_label': 30650,` (nächste freie ID im `#30xxx`-Bereich wählen).
2. Den passenden `msgctxt "#30xxx"`-Block in **allen** Sprachdateien
   `resources/language/resource.language.*/strings.po` (en_gb, en_us, nl_nl, ro_ro, sv_se)
   ergänzen.
Im Code dann über den **benannten Schlüssel** verwenden: `utils.i18n('my_label')` — NICHT die
rohe Zahl übergeben (`i18n` schlägt den Schlüssel in `STRINGS` nach und gibt sonst die Eingabe
unverändert zurück).

## Abschluss
- Manueller Kodi-Smoke-Test (keine automatisierten Tests im Repo).
- `utils.getHtml` ist gecacht → beim erneuten Testen Cache leeren (`utils.clear_cache()`).
