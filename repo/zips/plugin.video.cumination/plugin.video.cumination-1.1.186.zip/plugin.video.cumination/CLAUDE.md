# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What this is

Cumination (`plugin.video.cumination`) is a Kodi video plugin that aggregates 150+ adult
streaming sites into one addon. It is pure Python with no build step — Kodi loads `default.py`
directly. Code must stay Python 2/3 compatible: everything goes through `six` and `kodi_six`
(`from kodi_six import xbmc, xbmcplugin, ...`), and the codebase branches on `utils.PY3` /
`utils.KODIVER` for version-specific behavior.

## Versioning

`addon.xml` is the **single source of truth** for the version — never invent a version number
anywhere else. To bump, append a letter to the existing version (e.g. `1.1.186` → `1.1.186a`)
rather than assigning a new number. `changelog.txt` holds the human-readable changelog; its top
block (up to the first blank line) is shown to users once per version via `default.py:change()`.

## Build & release

There is no local build. CI (`.gitlab-ci.yml`) zips the addon into
`plugin.video.cumination.zip`. The `upload` and `release` stages only fire on a git tag matching
`vX.Y.Z`. There are **no automated tests** — verification is manual inside a running Kodi instance.

## Architecture

Everything is driven by a **mode-dispatch** pattern. Kodi re-invokes `default.py` for every user
action with a `?mode=<module>.<function>` query string; `URL_Dispatcher.dispatch()` looks the mode
up in a global registry and calls the matching function, coercing query params into its arguments.

- **`resources/lib/url_dispatcher.py`** — `URL_Dispatcher`. The `@register()` decorator records a
  function under `<module_name>.<func_name>` and introspects its signature so `dispatch()` can map
  query-string keys to positional args (required) and keyword args (optional). Helpers
  `add_dir` / `add_download_link` / `search_dir` build Kodi list items. String params arrive as
  strings; `"true"`/`"false"`/`"none"` are auto-coerced to Python types.

- **`resources/lib/adultsite.py`** — `AdultSite(URL_Dispatcher)`. One instance per site. Tracks all
  instances in a `WeakSet` so `site_list()` can enumerate them. `@site.register(default_mode=True)`
  marks the entry-point function for that site (exactly one per site).

- **`resources/lib/sites/`** — 150+ scrapers, one file per site, auto-imported via
  `from resources.lib.sites import *` (`sites/__init__.py` globs the directory). **This is where
  almost all feature work happens.** Each file is self-contained: create
  `site = AdultSite("name", "[COLOR ...]Title[/COLOR]", "https://url/", "image.png", "aboutfile")`,
  then decorate functions with `@site.register()`. See `resources/lib/sites/beeg.py` for a complete
  example (list → categories → `add_download_link` → `Playvid`). Each site has a matching
  `resources/about/<aboutfile>.txt` shown in the context menu.

- **`resources/lib/basics.py`** — list-item construction (`addDir`, `addDownLink`, `addImgLink`),
  path constants, image lookup (`cum_image`), and the **sqlite favorites DB** (`favoritesdb` in the
  addon profile dir). `eod()` ends the directory listing.

- **`resources/lib/utils.py`** — the scraping toolkit sites rely on:
  - `getHtml` / `postHtml` — HTTP with cookie persistence; `getHtml` is **cached** via
    `script.common.plugin.cache`. Use `clear_cache()` to invalidate.
  - `VideoPlayer` — resolves a page/link to a playable stream and plays it. Methods like
    `play_from_site_link`, `play_from_html`, `play_from_direct_link` cover the common cases and
    integrate `resolveurl`. This is the preferred way for a site's `Playvid` function to play.
  - Cloudflare/anti-bot handling (`flaresolve`, `streamdefence`, sucuri cookies), search helpers
    (`newSearch`, `oneSearch`, keyword backup/restore), quality selection (`prefquality`), and
    i18n (`i18n` → `resources/language/`).

- **`resources/lib/favorites.py` + `customsite.py`** — favorites, custom lists, and **user-installed
  custom sites**. Custom sites are `CustomSite(AdultSite)` instances loaded at runtime from the
  profile's `custom_sites/` dir (gated by the `custom_sites` setting); a failing custom site is
  auto-disabled with a user notice (see `default.py` top-level loop). Custom-site data lives in the
  same sqlite DB.

- **`default.py`** — entry point. Builds the root menu (`INDEX`), shows the age gate and PIN
  (`pin.py`) once, loads enabled custom sites, then routes the request via `process_queries` →
  `url_dispatcher.dispatch`. Setting `enh_debug` wraps execution in `exception_logger`.

## Conventions

- **Display strings use Kodi BBCode color tags**, e.g. `'[COLOR hotpink]Beeg[/COLOR]'`. Titles are
  stored with tags; `AdultSite.get_clean_title()` strips them for sorting.
- **Context-menu actions** are built as `RunPlugin(...)` / `Container.Update(...)` strings pointing
  back at `utils.addon_sys + "?mode=..."` with URL-encoded params (see `beeg.py:ContextRelated`).
- Pagination convention: add a `Next Page` dir item whose `mode` re-enters the list function with an
  incremented `page`; `utils.next_page` helps derive the next URL.
- Keep new strings translatable via `utils.i18n(...)` where user-facing.
